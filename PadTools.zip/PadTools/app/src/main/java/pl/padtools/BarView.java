package pl.padtools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** A labelled horizontal bar. Centered bars show -1..1, normal bars 0..1. */
final class BarView extends View {

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private final boolean centered;
    private final String name;
    private float fraction;
    private String text = "";
    private final RectF rect = new RectF();

    BarView(Context ctx, String name, boolean centered, int color) {
        super(ctx);
        this.name = name;
        this.centered = centered;
        density = ctx.getResources().getDisplayMetrics().density;
        bg.setColor(Color.parseColor("#26304A"));
        fill.setColor(color);
        label.setColor(Color.parseColor("#9AA7C2"));
        label.setTextSize(13 * density);
        value.setColor(Color.parseColor("#E8EDF7"));
        value.setTextSize(13 * density);
        value.setTextAlign(Paint.Align.RIGHT);
    }

    void set(float fraction, String text) {
        float f = centered ? Math.max(-1f, Math.min(1f, fraction)) : Math.max(0f, Math.min(1f, fraction));
        if (f == this.fraction && text.equals(this.text)) return;
        this.fraction = f;
        this.text = text;
        invalidate();
    }

    void setColor(int color) {
        fill.setColor(color);
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), (int) (34 * density));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        c.drawText(name, 0, 13 * density, label);
        c.drawText(text, w, 13 * density, value);
        float top = 19 * density, bottom = 29 * density, rad = 5 * density;
        rect.set(0, top, w, bottom);
        c.drawRoundRect(rect, rad, rad, bg);
        if (centered) {
            float mid = w / 2f, end = mid + fraction * w / 2f;
            rect.set(Math.min(mid, end), top, Math.max(mid, end), bottom);
        } else {
            rect.set(0, top, fraction * w, bottom);
        }
        if (rect.width() > 0) c.drawRoundRect(rect, rad, rad, fill);
    }
}
