package pl.padtools;

import java.util.HashMap;
import java.util.Map;

/**
 * Minimal HID report descriptor parser.
 * Returns the payload size (in bytes, without the report ID byte) of every
 * Feature report, so requests can be padded the same way WebHID does it.
 */
final class HidDescriptor {

    private HidDescriptor() {}

    static Map<Integer, Integer> featureReportSizes(byte[] d, int len) {
        Map<Integer, Integer> bits = new HashMap<>();
        int reportSize = 0, reportCount = 0, reportId = 0;
        int[][] stack = new int[8][];
        int sp = 0;

        int i = 0;
        while (i < len) {
            int b = d[i] & 0xff;
            if (b == 0xFE) { // long item
                if (i + 1 >= len) break;
                int dataSize = d[i + 1] & 0xff;
                i += 3 + dataSize;
                continue;
            }
            int sizeCode = b & 0x03;
            int size = sizeCode == 3 ? 4 : sizeCode;
            int type = (b >> 2) & 0x03;
            int tag = (b >> 4) & 0x0f;
            if (i + size >= len) break; // item would run past the end

            long value = 0;
            for (int k = 0; k < size; k++) {
                value |= (long) (d[i + 1 + k] & 0xff) << (8 * k);
            }

            if (type == 1) { // global
                switch (tag) {
                    case 7: reportSize = (int) value; break;
                    case 8: reportId = (int) value; break;
                    case 9: reportCount = (int) value; break;
                    case 10: // push
                        if (sp < stack.length) stack[sp++] = new int[]{reportSize, reportCount, reportId};
                        break;
                    case 11: // pop
                        if (sp > 0) {
                            int[] s = stack[--sp];
                            reportSize = s[0]; reportCount = s[1]; reportId = s[2];
                        }
                        break;
                    default: break;
                }
            } else if (type == 0 && tag == 0x0B) { // main: Feature
                Integer prev = bits.get(reportId);
                bits.put(reportId, (prev == null ? 0 : prev) + reportSize * reportCount);
            }
            i += 1 + size;
        }

        Map<Integer, Integer> bytes = new HashMap<>();
        for (Map.Entry<Integer, Integer> e : bits.entrySet()) {
            bytes.put(e.getKey(), (e.getValue() + 7) / 8);
        }
        return bytes;
    }
}
