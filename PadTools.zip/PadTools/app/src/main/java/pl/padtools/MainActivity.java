package pl.padtools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String ACTION_USB_PERMISSION = "pl.padtools.USB_PERMISSION";

    static final int BG = Color.parseColor("#0F1522");
    static final int CARD = Color.parseColor("#182033");
    static final int CHIP = Color.parseColor("#26304A");
    static final int TEXT = Color.parseColor("#E8EDF7");
    static final int MUTED = Color.parseColor("#9AA7C2");
    static final int ACCENT = Color.parseColor("#4DA3FF");
    static final int OK = Color.parseColor("#3DDC84");
    static final int DANGER = Color.parseColor("#FF6B6B");
    static final int WARN = Color.parseColor("#FFC24B");

    private UsbManager usb;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<String> permissionAsked = new HashSet<>();

    // connection
    private volatile HidUsbDevice hid;
    private volatile int connectedPid;
    private volatile boolean connecting;
    private volatile boolean reading;
    private Thread inputThread;
    private ControllerProtocol.Info lastInfo;
    private volatile InputState state;
    private volatile OutputController out;
    private volatile Calibration cal;
    private boolean started;
    private boolean unsavedCalibration;

    // header
    private TextView status;
    private Button shareBtn;
    private LinearLayout tabBar;
    private final TextView[] tabs = new TextView[4];
    private final LinearLayout[] pages = new LinearLayout[4];
    private int currentTab;

    // info page
    private TextView boardBig, boardSub, modelText;
    private LinearLayout boardCard, warnBox, infoTable, infoCard;

    // test page
    private StickView sticks;
    private TextView rateText;
    private LinearLayout buttonGrid;
    private TextView buttonCount;
    private TextView[] chips = new TextView[0];
    private BarView barL2, barR2, battery;
    private TextView triggerMax;
    private TouchpadView touchpad;
    private TextView touchText;
    private BarView[] gyroBars = new BarView[3], accelBars = new BarView[3];
    private LinearLayout testPage;
    private long lastPackets, lastRateTime;

    // outputs page
    private LinearLayout outputsContent;

    // calibration page
    private LinearLayout calibContent;

    // range dialog
    private AlertDialog rangeDialog;
    private StickView rangeSticks;
    private TextView rangeProgress;
    private Button rangeDone;
    private long rangeStart;
    private final float[] covL = new float[InputState.RANGE_BINS], covR = new float[InputState.RANGE_BINS];

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            renderFrame();
            if (started) main.postDelayed(this, 33);
        }
    };

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                scanAndConnect(false);
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice d = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                HidUsbDevice cur = hid;
                if (cur != null && d != null && d.getDeviceName().equals(cur.device.getDeviceName())) {
                    onPadGone();
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                scanAndConnect(true);
            }
        }
    };

    // ================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(usbReceiver, f);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
            scanAndConnect(true);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        started = true;
        main.post(frame);
        if (hid == null) {
            scanAndConnect(false);
        } else {
            startInput();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        started = false;
        main.removeCallbacks(frame);
        stopInput();
        final OutputController o = out;
        if (o != null) io.execute(o::reset);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(usbReceiver);
        } catch (Exception ignored) {
        }
        stopInput();
        final HidUsbDevice h = hid;
        final OutputController o = out;
        hid = null;
        out = null;
        io.execute(() -> {
            if (o != null) o.reset();
            if (h != null) h.close();
        });
        io.shutdown();
    }

    // ================================================================== USB flow

    private UsbDevice findController() {
        for (UsbDevice d : usb.getDeviceList().values()) {
            if (ControllerProtocol.isSupported(d.getVendorId(), d.getProductId())) return d;
        }
        for (UsbDevice d : usb.getDeviceList().values()) {
            if (d.getVendorId() == ControllerProtocol.SONY_VID) return d;
        }
        return null;
    }

    private void scanAndConnect(boolean mayAskPermission) {
        if (hid != null || connecting) return;
        UsbDevice d = findController();
        if (d == null) {
            setStatus("Nie wykryto pada. Podłącz DualSense lub DualShock 4 kablem USB (OTG) do telefonu.", MUTED);
            return;
        }
        if (!ControllerProtocol.isSupported(d.getVendorId(), d.getProductId())) {
            setStatus(String.format("Wykryto urządzenie Sony (PID %04X), ale ten model nie jest obsługiwany.", d.getProductId()), WARN);
            return;
        }
        if (!usb.hasPermission(d)) {
            if (!mayAskPermission && permissionAsked.contains(d.getDeviceName())) {
                setStatus("Brak zgody na dostęp do pada. Stuknij „Połącz”, aby zapytać ponownie.", WARN);
                return;
            }
            permissionAsked.add(d.getDeviceName());
            setStatus("Zezwól aplikacji na dostęp do pada w oknie systemowym…", ACCENT);
            Intent i = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
            int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
            PendingIntent pi = PendingIntent.getBroadcast(this, 0, i, flags);
            usb.requestPermission(d, pi);
            return;
        }
        connect(d);
    }

    private void connect(final UsbDevice d) {
        connecting = true;
        final int pid = d.getProductId();
        setStatus("Łączenie z " + ControllerProtocol.modelName(pid) + "…", ACCENT);
        io.execute(() -> {
            HidUsbDevice h = null;
            try {
                h = HidUsbDevice.open(usb, d);
                final ControllerProtocol.Info info = ControllerProtocol.read(h, pid);
                boolean ds5 = ControllerProtocol.isDualSense(pid);
                boolean edge = pid == ControllerProtocol.PID_DS5_EDGE;
                Calibration c = new Calibration(h, ds5);
                if (!info.clone && !edge && Boolean.FALSE.equals(c.nvLocked())) {
                    // same as dualshock-tools: re-lock NVS if a previous tool left it open
                    try { c.nvLock(); } catch (Exception ignored) { }
                }
                OutputController o = new OutputController(h, ds5, info.updateVersion);
                try { o.init(); } catch (Exception ignored) { }

                state = new InputState(ds5, edge);
                cal = c;
                out = o;
                hid = h;
                connectedPid = pid;
                main.post(() -> {
                    connecting = false;
                    unsavedCalibration = false;
                    showInfo(info);
                    buildTestPage();
                    buildOutputsPage();
                    buildCalibrationPage();
                    tabBar.setVisibility(View.VISIBLE);
                    showTab(currentTab);
                    setStatus("Połączono przez USB.", OK);
                    if (started) startInput();
                });
            } catch (Exception e) {
                if (h != null) h.close();
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                main.post(() -> {
                    connecting = false;
                    setStatus("Błąd: " + msg + "\nOdłącz i podłącz pada ponownie, potem stuknij „Połącz”.", DANGER);
                });
            }
        });
    }

    private void onPadGone() {
        boolean lost = unsavedCalibration;
        disconnect();
        setStatus(lost
                ? "Pad odłączony. Niezapisana kalibracja została utracona."
                : "Pad odłączony. Podłącz go ponownie kablem USB.", lost ? WARN : MUTED);
        if (rangeDialog != null) {
            rangeDialog.dismiss();
            rangeDialog = null;
        }
    }

    private void disconnect() {
        stopInput();
        final HidUsbDevice h = hid;
        hid = null;
        out = null;
        cal = null;
        unsavedCalibration = false;
        if (h != null) io.execute(h::close);
        if (sticks != null) sticks.reset();
        if (tabBar != null) {
            tabBar.setVisibility(View.GONE);
            for (int i = 1; i < pages.length; i++) pages[i].setVisibility(View.GONE);
            pages[0].setVisibility(View.VISIBLE);
        }
    }

    private void startInput() {
        final HidUsbDevice h = hid;
        final InputState s = state;
        if (h == null || s == null || reading) return;
        reading = true;
        inputThread = new Thread(() -> {
            byte[] buf = new byte[h.inputPacketSize()];
            int errors = 0;
            while (reading) {
                int n = h.readInput(buf, 200);
                if (n > 0) {
                    errors = 0;
                    s.parse(buf, n);
                } else if (++errors > 50) {
                    break;
                }
            }
            reading = false;
        }, "pad-input");
        inputThread.start();
    }

    private void stopInput() {
        reading = false;
        Thread t = inputThread;
        inputThread = null;
        if (t != null) {
            try {
                t.join(500);
            } catch (InterruptedException ignored) {
            }
        }
    }

    /** Runs a USB command on the worker thread and reports errors in a toast. */
    private void usbTask(final UsbRunnable r) {
        io.execute(() -> {
            try {
                r.run();
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                main.post(() -> Toast.makeText(this, "Błąd: " + msg, Toast.LENGTH_LONG).show());
            }
        });
    }

    interface UsbRunnable {
        void run() throws Exception;
    }

    // ================================================================== UI skeleton

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(root);

        root.addView(text("PadTools", 26, TEXT, true));
        TextView sub = text("Test i kalibracja pada PS5 / PS4 przez kabel USB", 14, MUTED, false);
        sub.setPadding(0, dp(2), 0, dp(14));
        root.addView(sub);

        status = text("", 14, MUTED, false);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.setBackground(rounded(CARD));
        root.addView(status, lp());

        LinearLayout buttons = row();
        buttons.setPadding(0, dp(10), 0, dp(4));
        Button connectBtn = button("Połącz", ACCENT);
        connectBtn.setOnClickListener(v -> {
            if (connecting) return;
            disconnect();
            scanAndConnect(true);
        });
        shareBtn = button("Udostępnij", CHIP);
        shareBtn.setEnabled(false);
        shareBtn.setOnClickListener(v -> shareInfo());
        addWeighted(buttons, connectBtn, shareBtn);
        root.addView(buttons, lp());

        tabBar = row();
        tabBar.setPadding(0, dp(10), 0, 0);
        String[] names = {"Info", "Test", "Wyjścia", "Kalibracja"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = text(names[i], 14, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(v -> showTab(idx));
            tabs[i] = t;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) p.leftMargin = dp(4);
            tabBar.addView(t, p);
        }
        tabBar.setVisibility(View.GONE);
        root.addView(tabBar, lp());

        for (int i = 0; i < 4; i++) {
            pages[i] = column();
            pages[i].setVisibility(i == 0 ? View.VISIBLE : View.GONE);
            root.addView(pages[i], lp());
        }
        buildInfoPage(pages[0]);
        testPage = pages[1];
        outputsContent = pages[2];
        calibContent = pages[3];

        TextView help = text(
                "Jak podłączyć: kabel USB-C ↔ USB-C (PS5) albo przejściówka OTG + kabel micro-USB (PS4). "
                        + "Bluetooth nie jest obsługiwany.\n\n"
                        + "Na podstawie projektu dualshock-tools (licencja MIT).",
                12, MUTED, false);
        help.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(help, lp());
        return scroll;
    }

    private void showTab(int idx) {
        currentTab = idx;
        for (int i = 0; i < 4; i++) {
            boolean sel = i == idx;
            pages[i].setVisibility(sel ? View.VISIBLE : View.GONE);
            tabs[i].setTextColor(sel ? Color.WHITE : MUTED);
            tabs[i].setBackground(rounded(sel ? ACCENT : CARD));
        }
        if (idx != 2) {
            final OutputController o = out;
            if (o != null) io.execute(o::reset); // stop rumble / triggers when leaving outputs
        }
    }

    // ================================================================== info page

    private void buildInfoPage(LinearLayout page) {
        boardCard = card();
        modelText = text("", 14, MUTED, false);
        boardCard.addView(modelText);
        boardBig = text("", 34, TEXT, true);
        boardBig.setPadding(0, dp(2), 0, dp(2));
        boardCard.addView(boardBig);
        boardSub = text("", 13, MUTED, false);
        boardCard.addView(boardSub);
        boardCard.setVisibility(View.GONE);
        page.addView(boardCard, cardLp());

        warnBox = column();
        page.addView(warnBox, lp());

        infoCard = card();
        infoCard.addView(sectionTitle("Szczegóły"));
        infoTable = column();
        infoCard.addView(infoTable, lp());
        infoCard.setVisibility(View.GONE);
        page.addView(infoCard, cardLp());
    }

    private void showInfo(ControllerProtocol.Info info) {
        lastInfo = info;
        modelText.setText(info.model);
        boardBig.setText(info.clone ? "Podróbka?" : info.board);
        boardBig.setTextColor(info.clone ? DANGER : TEXT);
        boardSub.setText(info.clone
                ? "Pad nie odpowiada jak oryginalny kontroler Sony – dane mogą być niewiarygodne."
                : info.boardNote);
        boardCard.setVisibility(View.VISIBLE);

        warnBox.removeAllViews();
        for (String w : info.warnings) {
            TextView t = text("⚠ " + w, 13, WARN, false);
            t.setPadding(dp(14), dp(10), dp(14), dp(10));
            t.setBackground(rounded(CARD));
            warnBox.addView(t, cardLp());
        }

        infoTable.removeAllViews();
        for (String[] row : info.rows) {
            LinearLayout r = column();
            r.setPadding(0, dp(7), 0, dp(7));
            r.addView(text(row[0], 12, MUTED, false));
            TextView v = text(row[1], 15, row[1].startsWith("PODRÓBKA") ? DANGER : TEXT, false);
            v.setTypeface(Typeface.MONOSPACE);
            v.setTextIsSelectable(true);
            r.addView(v);
            final String copy = row[1];
            r.setOnLongClickListener(x -> {
                copyToClipboard(copy);
                return true;
            });
            infoTable.addView(r, lp());
        }
        infoCard.setVisibility(View.VISIBLE);
        shareBtn.setEnabled(true);
    }

    // ================================================================== test page

    private void buildTestPage() {
        testPage.removeAllViews();
        InputState s = state;
        boolean ds5 = s != null && s.ds5;

        // sticks
        LinearLayout c = card();
        c.addView(sectionTitle("Analogi"));
        c.addView(hint("Puść gałki i sprawdź odchylenie od środka. Zielone (poniżej 3%) = bez dryfu."));
        sticks = new StickView(this);
        c.addView(sticks, lp());
        rateText = text("", 12, MUTED, false);
        c.addView(rateText);
        testPage.addView(c, cardLp());

        // buttons
        c = card();
        c.addView(sectionTitle("Przyciski"));
        c.addView(hint("Naciśnij każdy przycisk – sprawdzone zmienią kolor na zielony."));
        buttonGrid = column();
        c.addView(buttonGrid, lp());
        LinearLayout r = row();
        r.setPadding(0, dp(8), 0, 0);
        buttonCount = text("", 14, TEXT, true);
        buttonCount.setGravity(Gravity.CENTER_VERTICAL);
        Button reset = button("Od nowa", CHIP);
        reset.setOnClickListener(v -> {
            InputState st = state;
            if (st != null) st.resetSeen();
            if (touchpad != null) touchpad.clear();
        });
        addWeighted(r, buttonCount, reset);
        c.addView(r, lp());
        testPage.addView(c, cardLp());
        buildChips();

        // triggers
        c = card();
        c.addView(sectionTitle("Triggery L2 / R2"));
        barL2 = new BarView(this, "L2", false, ACCENT);
        barR2 = new BarView(this, "R2", false, ACCENT);
        c.addView(barL2, lp());
        c.addView(barR2, lp());
        triggerMax = text("", 12, MUTED, false);
        c.addView(triggerMax);
        testPage.addView(c, cardLp());

        // touchpad
        c = card();
        c.addView(sectionTitle("Touchpad"));
        c.addView(hint("Rysuj palcem po touchpadzie, dotknij dwoma palcami i kliknij go."));
        touchpad = new TouchpadView(this, ds5);
        c.addView(touchpad, lp());
        touchText = text("", 12, MUTED, false);
        touchText.setPadding(0, dp(6), 0, 0);
        c.addView(touchText);
        testPage.addView(c, cardLp());

        // motion sensors
        c = card();
        c.addView(sectionTitle("Żyroskop i akcelerometr"));
        c.addView(hint("Obróć pada wokół każdej osi. W spoczynku akcelerometr pokazuje ok. 1 g łącznie."));
        String[] g = {"Żyro X (pochylenie)", "Żyro Y (odchylenie)", "Żyro Z (przechył)"};
        String[] a = {"Akcel. X", "Akcel. Y", "Akcel. Z"};
        int[] col = {Color.parseColor("#FF6B6B"), Color.parseColor("#3DDC84"), ACCENT};
        for (int i = 0; i < 3; i++) {
            gyroBars[i] = new BarView(this, g[i], true, col[i]);
            c.addView(gyroBars[i], lp());
        }
        for (int i = 0; i < 3; i++) {
            accelBars[i] = new BarView(this, a[i], true, col[i]);
            c.addView(accelBars[i], lp());
        }
        testPage.addView(c, cardLp());

        // battery
        c = card();
        c.addView(sectionTitle("Bateria"));
        battery = new BarView(this, "Poziom", false, OK);
        c.addView(battery, lp());
        testPage.addView(c, cardLp());
    }

    private void buildChips() {
        InputState s = state;
        if (s == null) return;
        buttonGrid.removeAllViews();
        int mask = s.buttonMask();
        int count = 0;
        for (int i = 0; i < InputState.BUTTON_COUNT; i++) if ((mask & (1 << i)) != 0) count++;
        chips = new TextView[InputState.BUTTON_COUNT];
        chipState = new int[InputState.BUTTON_COUNT];
        LinearLayout r = null;
        int inRow = 0;
        for (int i = 0; i < InputState.BUTTON_COUNT; i++) {
            if ((mask & (1 << i)) == 0) continue;
            if (r == null || inRow == 4) {
                r = row();
                buttonGrid.addView(r, lp());
                inRow = 0;
            }
            TextView t = text(InputState.buttonName(i, s.ds5), 14, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            t.setBackground(rounded(CHIP));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(t, p);
            chips[i] = t;
            inRow++;
        }
        while (r != null && inRow < 4) { // keep the last row aligned
            View filler = new View(this);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 1, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(filler, p);
            inRow++;
        }
        buttonCount.setTag(count);
    }

    private int[] chipState = new int[InputState.BUTTON_COUNT];

    private void renderFrame() {
        InputState s = state;
        if (s == null || hid == null) return;

        if (rangeDialog != null && rangeSticks != null) renderRange(s);
        if (currentTab != 1 || sticks == null) return;

        sticks.setRaw(s.lx, s.ly, s.rx, s.ry);

        long now = System.currentTimeMillis();
        if (now - lastRateTime >= 1000) {
            long p = s.packets;
            if (lastRateTime != 0) {
                long rate = (p - lastPackets) * 1000 / Math.max(1, now - lastRateTime);
                rateText.setText("Częstotliwość raportów: " + rate + " Hz");
            }
            lastPackets = p;
            lastRateTime = now;
        }

        int pressed = s.buttons, seen = s.seenButtons, done = 0;
        Object total = buttonCount.getTag();
        for (int i = 0; i < chips.length; i++) {
            TextView t = chips[i];
            if (t == null) continue;
            int st = (pressed & (1 << i)) != 0 ? 2 : (seen & (1 << i)) != 0 ? 1 : 0;
            if (st > 0) done++;
            if (chipState[i] == st) continue;
            chipState[i] = st;
            if (st == 2) {
                t.setBackground(rounded(ACCENT));
                t.setTextColor(Color.WHITE);
            } else if (st == 1) {
                t.setBackground(rounded(Color.parseColor("#1E3B2E")));
                t.setTextColor(OK);
            } else {
                t.setBackground(rounded(CHIP));
                t.setTextColor(MUTED);
            }
        }
        buttonCount.setText("Sprawdzone: " + done + " / " + total);
        buttonCount.setTextColor(total != null && done == (Integer) total ? OK : TEXT);

        barL2.set(s.l2 / 255f, String.valueOf(s.l2));
        barR2.set(s.r2 / 255f, String.valueOf(s.r2));
        triggerMax.setText("Maksymalnie wciśnięte: L2 " + s.maxL2 + " / R2 " + s.maxR2 + " (255 = do końca)");

        boolean[] act = s.touchActive;
        boolean click = (pressed & (1 << InputState.TOUCHPAD)) != 0;
        touchpad.update(act, s.touchX, s.touchY, click);
        int fingers = (act[0] ? 1 : 0) + (act[1] ? 1 : 0);
        touchText.setText("Palce: " + fingers + (click ? "  •  kliknięty" : ""));

        float[] gv = {s.gx, s.gy, s.gz};
        float[] av = {s.ax, s.ay, s.az};
        for (int i = 0; i < 3; i++) {
            gyroBars[i].set(gv[i] / 360f, String.format("%+.0f °/s", gv[i]));
            accelBars[i].set(av[i] / 1.5f, String.format("%+.2f g", av[i]));
        }

        if (s.battery >= 0) {
            battery.set(s.battery / 100f, s.battery + "% – " + s.batteryText);
        } else {
            battery.set(0, s.batteryText);
        }
    }

    // ================================================================== outputs page

    private void buildOutputsPage() {
        outputsContent.removeAllViews();
        InputState s = state;
        boolean ds5 = s != null && s.ds5;

        LinearLayout c = card();
        c.addView(sectionTitle("Wibracje"));
        c.addView(hint("Lewy silnik jest mocniejszy (niskie drgania), prawy słabszy (wysokie)."));
        LinearLayout r = row();
        Button left = button("Lewy", CHIP);
        left.setOnClickListener(v -> rumble(255, 0));
        Button right = button("Prawy", CHIP);
        right.setOnClickListener(v -> rumble(0, 255));
        Button both = button("Oba", CHIP);
        both.setOnClickListener(v -> rumble(255, 255));
        addWeighted(r, left, right, both);
        c.addView(r, lp());
        outputsContent.addView(c, cardLp());

        c = card();
        c.addView(sectionTitle("Podświetlenie"));
        String[] names = {"Czerw.", "Ziel.", "Nieb.", "Biały", "Wył."};
        final int[][] colors = {{255, 0, 0}, {0, 255, 0}, {0, 0, 255}, {255, 255, 255}, {0, 0, 0}};
        r = row();
        Button[] cb = new Button[names.length];
        for (int i = 0; i < names.length; i++) {
            final int[] rgb = colors[i];
            cb[i] = button(names[i], CHIP);
            cb[i].setOnClickListener(v -> usbTask(() -> out().setLightbar(rgb[0], rgb[1], rgb[2])));
        }
        addWeighted(r, cb);
        c.addView(r, lp());
        if (ds5) {
            c.addView(subTitle("Diody gracza"));
            r = row();
            String[] pn = {"1", "2", "3", "4", "Wsz.", "Wył."};
            final int[] pat = {0x04, 0x0A, 0x15, 0x1B, 0x1F, 0x00};
            Button[] pb = new Button[pn.length];
            for (int i = 0; i < pn.length; i++) {
                final int p = pat[i];
                pb[i] = button(pn[i], CHIP);
                pb[i].setOnClickListener(v -> usbTask(() -> out().setPlayerLeds(p)));
            }
            addWeighted(r, pb);
            c.addView(r, lp());

            c.addView(subTitle("Dioda wyciszenia (Mute)"));
            r = row();
            String[] mn = {"Wył.", "Świeci", "Pulsuje"};
            Button[] mb = new Button[3];
            for (int i = 0; i < 3; i++) {
                final int m = i;
                mb[i] = button(mn[i], CHIP);
                mb[i].setOnClickListener(v -> usbTask(() -> out().setMuteLed(m)));
            }
            addWeighted(r, mb);
            c.addView(r, lp());
        }
        outputsContent.addView(c, cardLp());

        if (ds5) {
            c = card();
            c.addView(sectionTitle("Adaptacyjne triggery"));
            c.addView(hint("Włącz opór i wciśnij L2/R2, żeby go poczuć."));
            r = row();
            String[] tn = {"Wył.", "Lekki", "Średni", "Mocny"};
            Button[] tb = new Button[4];
            for (int i = 0; i < 4; i++) {
                final int p = i;
                tb[i] = button(tn[i], CHIP);
                tb[i].setOnClickListener(v -> usbTask(() -> out().setTriggerPreset(p)));
            }
            addWeighted(r, tb);
            c.addView(r, lp());
            outputsContent.addView(c, cardLp());

            c = card();
            c.addView(sectionTitle("Głośnik"));
            c.addView(hint("Pad odtworzy wbudowany dźwięk testowy."));
            r = row();
            Button on = button("Włącz dźwięk", CHIP);
            on.setOnClickListener(v -> usbTask(() -> out().speakerTone(true)));
            Button off = button("Wyłącz", CHIP);
            off.setOnClickListener(v -> usbTask(() -> out().speakerTone(false)));
            addWeighted(r, on, off);
            c.addView(r, lp());
            outputsContent.addView(c, cardLp());
        }

        c = card();
        Button stop = button("Wyłącz wszystko", DANGER);
        stop.setOnClickListener(v -> usbTask(() -> {
            OutputController o = out();
            o.reset();
            if (state != null && state.ds5) o.speakerTone(false);
        }));
        c.addView(stop, lp());
        outputsContent.addView(c, cardLp());
    }

    private OutputController out() throws Exception {
        OutputController o = out;
        if (o == null) throw new Exception("Pad nie jest podłączony");
        return o;
    }

    private void rumble(final int left, final int right) {
        usbTask(() -> {
            OutputController o = out();
            o.setRumble(left, right);
            Thread.sleep(1500);
            o.setRumble(0, 0);
        });
    }

    // ================================================================== calibration page

    private boolean calibrationAllowed() {
        return lastInfo != null && !lastInfo.clone && !lastInfo.oldFirmware
                && connectedPid != ControllerProtocol.PID_DS5_EDGE;
    }

    private void buildCalibrationPage() {
        calibContent.removeAllViews();
        LinearLayout c = card();
        c.addView(sectionTitle("Kalibracja analogów"));

        if (!calibrationAllowed()) {
            String why;
            if (lastInfo != null && lastInfo.clone) why = "Pad wygląda na podróbkę – kalibracja jest zablokowana, tak jak w dualshock-tools.";
            else if (lastInfo != null && lastInfo.oldFirmware) why = "Pad ma stary firmware (2020/2021). Zaktualizuj go na konsoli PS5, potem wróć tutaj.";
            else why = "DualSense Edge przechowuje kalibrację w wymiennych modułach analogów, a ich zapis wymaga osobnej procedury, której ta wersja aplikacji nie obsługuje. Do kalibracji Edge użyj dualshock-tools na komputerze.";
            TextView t = text(why, 14, WARN, false);
            c.addView(t);
            calibContent.addView(c, cardLp());
            return;
        }

        c.addView(hint("Zalecana kolejność po wymianie analogów: 1) kalibracja środka, 2) kalibracja zakresu, "
                + "3) sprawdzenie w zakładce Test, 4) zapis na stałe.\n\n"
                + "Nowa kalibracja działa od razu, ale jest tymczasowa – zniknie po wyłączeniu lub odłączeniu pada, "
                + "dopóki nie stukniesz „Zapisz na stałe”."));

        Button center = button("1. Kalibracja środka", ACCENT);
        center.setOnClickListener(v -> startCenterWizard());
        c.addView(center, buttonLp());

        Button range = button("2. Kalibracja zakresu", ACCENT);
        range.setOnClickListener(v -> startRangeCalibration());
        c.addView(range, buttonLp());
        calibContent.addView(c, cardLp());

        c = card();
        c.addView(sectionTitle("Zapis"));
        final TextView st = text("", 14, MUTED, false);
        st.setTag("calib-status");
        c.addView(st);
        Button save = button("Zapisz na stałe", OK);
        save.setOnClickListener(v -> confirmSave());
        c.addView(save, buttonLp());
        Button discard = button("Odrzuć zmiany (restart pada)", CHIP);
        discard.setOnClickListener(v -> confirmDiscard());
        c.addView(discard, buttonLp());
        calibContent.addView(c, cardLp());
        refreshCalibStatus();
    }

    private void refreshCalibStatus() {
        View v = calibContent.findViewWithTag("calib-status");
        if (!(v instanceof TextView)) return;
        TextView t = (TextView) v;
        if (unsavedCalibration) {
            t.setText("Masz niezapisaną kalibrację (działa do wyłączenia pada).");
            t.setTextColor(WARN);
        } else {
            t.setText("Brak niezapisanych zmian.");
            t.setTextColor(MUTED);
        }
    }

    // ---------- center wizard (same steps as dualshock-tools)

    private static final String[] CENTER_STEPS = {
            "Kreator przesunie środek obu analogów.\n\nBędziesz 4 razy proszony o wychylenie obu gałek w róg i puszczenie ich. "
                    + "Po rozpoczęciu nie da się przerwać kalibracji – nie odłączaj pada do końca.\n\nStuknij „Start”.",
            "Krok 1/4: wychyl obie gałki w LEWY GÓRNY róg i puść je.\nGdy wrócą na środek, stuknij „Dalej”.",
            "Krok 2/4: wychyl obie gałki w PRAWY GÓRNY róg i puść je.\nGdy wrócą na środek, stuknij „Dalej”.",
            "Krok 3/4: wychyl obie gałki w LEWY DOLNY róg i puść je.\nGdy wrócą na środek, stuknij „Dalej”.",
            "Krok 4/4: wychyl obie gałki w PRAWY DOLNY róg i puść je.\nGdy wrócą na środek, stuknij „Dalej”.",
    };

    private int centerStep;

    private void startCenterWizard() {
        if (cal == null) return;
        centerStep = 0;
        final TextView msg = text(CENTER_STEPS[0], 15, TEXT, false);
        msg.setPadding(dp(20), dp(16), dp(20), dp(8));
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Kalibracja środka")
                .setView(msg)
                .setPositiveButton("Start", null)
                .setNegativeButton("Anuluj", null)
                .setCancelable(false)
                .create();
        d.setOnShowListener(x -> {
            final Button next = d.getButton(DialogInterface.BUTTON_POSITIVE);
            final Button cancel = d.getButton(DialogInterface.BUTTON_NEGATIVE);
            next.setOnClickListener(v -> centerNext(d, msg, next, cancel));
        });
        d.show();
    }

    private void centerNext(final AlertDialog d, final TextView msg, final Button next, final Button cancel) {
        final Calibration c = cal;
        if (c == null) {
            d.dismiss();
            return;
        }
        final int step = centerStep;
        if (step > CENTER_STEPS.length) { // finished
            d.dismiss();
            return;
        }
        next.setEnabled(false);
        cancel.setVisibility(View.GONE);
        msg.setText(step == 0 ? "Przygotowanie…" : "Próbkowanie…");
        io.execute(() -> {
            try {
                if (step == 0) {
                    Calibration.sleep(100);
                    c.centerBegin();
                } else if (step < 4) {
                    Calibration.sleep(150);
                    c.centerSample();
                } else {
                    Calibration.sleep(150);
                    c.centerSample();
                    Calibration.sleep(700);
                    c.centerEnd();
                }
                main.post(() -> {
                    centerStep = step + 1;
                    next.setEnabled(true);
                    if (centerStep < CENTER_STEPS.length) {
                        msg.setText(CENTER_STEPS[centerStep]);
                        next.setText("Dalej");
                    } else {
                        centerStep = CENTER_STEPS.length + 1;
                        msg.setText("Kalibracja środka zakończona!\n\nSprawdź analogi w zakładce Test, a potem zapisz zmiany na stałe.");
                        msg.setTextColor(OK);
                        next.setText("Gotowe");
                        unsavedCalibration = true;
                        refreshCalibStatus();
                    }
                });
            } catch (Exception e) {
                final String err = e.getMessage() == null ? e.toString() : e.getMessage();
                main.post(() -> {
                    centerStep = CENTER_STEPS.length + 1;
                    msg.setText("Kalibracja nie powiodła się:\n" + err
                            + "\n\nOdłącz i podłącz pada (to przywraca poprzednią kalibrację) i spróbuj ponownie.");
                    msg.setTextColor(DANGER);
                    next.setText("Zamknij");
                    next.setEnabled(true);
                });
            }
        });
    }

    // ---------- range calibration

    private static final int RANGE_MIN_SECONDS = 15;
    private static final int RANGE_CYCLES = 4;

    private void startRangeCalibration() {
        final Calibration c = cal;
        final InputState s = state;
        if (c == null || s == null) return;

        LinearLayout box = column();
        box.setPadding(dp(20), dp(12), dp(20), dp(4));
        box.addView(text("Kręć obiema gałkami powoli po pełnym okręgu, dociskając je do krawędzi, aż pasek dojdzie do 100%.", 14, TEXT, false));
        rangeSticks = new StickView(this);
        LinearLayout.LayoutParams sp = lp();
        sp.topMargin = dp(10);
        box.addView(rangeSticks, sp);
        rangeProgress = text("Przygotowanie…", 15, ACCENT, true);
        box.addView(rangeProgress);

        rangeStart = System.currentTimeMillis();
        s.startRangeTracking();
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Kalibracja zakresu")
                .setView(box)
                .setPositiveButton("Gotowe", null)
                .setCancelable(false)
                .create();
        d.setOnShowListener(x -> {
            rangeDone = d.getButton(DialogInterface.BUTTON_POSITIVE);
            rangeDone.setEnabled(false);
            rangeDone.setOnClickListener(v -> finishRange(d));
        });
        rangeDialog = d;
        d.show();

        io.execute(() -> {
            try {
                Calibration.sleep(1000);
                c.rangeBegin();
            } catch (Exception e) {
                final String err = e.getMessage() == null ? e.toString() : e.getMessage();
                main.post(() -> {
                    s.stopRangeTracking();
                    if (rangeDialog == d) rangeDialog = null;
                    d.dismiss();
                    showMessage("Kalibracja zakresu", "Nie udało się rozpocząć kalibracji:\n" + err);
                });
            }
        });
    }

    private void renderRange(InputState s) {
        s.copyRange(true, covL);
        s.copyRange(false, covR);
        rangeSticks.setRaw(s.lx, s.ly, s.rx, s.ry);
        rangeSticks.setCoverage(covL, covR);

        float left = Math.min(1f, (s.leftCycles + s.rangeFill(true)) / RANGE_CYCLES);
        float right = Math.min(1f, (s.rightCycles + s.rangeFill(false)) / RANGE_CYCLES);
        int progress = Math.round((left + right) * 50);
        long secs = (System.currentTimeMillis() - rangeStart) / 1000;
        boolean ready = progress >= 100 || secs >= RANGE_MIN_SECONDS;
        rangeProgress.setText("Postęp: " + progress + "%" + (ready ? "" : "   (min. " + (RANGE_MIN_SECONDS - secs) + " s)"));
        rangeProgress.setTextColor(progress >= 100 ? OK : ACCENT);
        if (rangeDone != null && ready && !rangeDone.isEnabled() && rangeDone.getTag() == null) {
            rangeDone.setEnabled(true);
        }
    }

    private void finishRange(final AlertDialog d) {
        final Calibration c = cal;
        final InputState s = state;
        rangeDone.setEnabled(false);
        rangeDone.setTag("busy");
        rangeProgress.setText("Zapisywanie…");
        io.execute(() -> {
            String err = null;
            try {
                if (c == null) throw new Exception("Pad nie jest podłączony");
                c.rangeEnd();
            } catch (Exception e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String error = err;
            main.post(() -> {
                if (s != null) s.stopRangeTracking();
                rangeDialog = null;
                rangeSticks = null;
                rangeDone = null;
                d.dismiss();
                if (error == null) {
                    unsavedCalibration = true;
                    refreshCalibStatus();
                    showMessage("Kalibracja zakresu", "Gotowe! Sprawdź analogi w zakładce Test, a potem zapisz zmiany na stałe.");
                } else {
                    showMessage("Kalibracja zakresu", "Nie udało się zapisać kalibracji:\n" + error
                            + "\n\nOdłącz i podłącz pada, aby przywrócić poprzednią kalibrację.");
                }
            });
        });
    }

    // ---------- save / discard

    private void confirmSave() {
        if (!unsavedCalibration) {
            showMessage("Zapis", "Nie ma niezapisanej kalibracji. Najpierw wykonaj kalibrację środka lub zakresu.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Zapisać na stałe?")
                .setMessage("Nowa kalibracja zostanie zapisana w pamięci pada i zastąpi fabryczną. "
                        + "Nie odłączaj pada w trakcie zapisu. Upewnij się w zakładce Test, że analogi działają dobrze.")
                .setPositiveButton("Zapisz", (x, w) -> doSave())
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void doSave() {
        final Calibration c = cal;
        if (c == null) return;
        setStatus("Zapisywanie kalibracji w padzie…", ACCENT);
        io.execute(() -> {
            String err = null;
            try {
                c.savePermanently();
            } catch (Exception e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String error = err;
            main.post(() -> {
                if (error == null) {
                    unsavedCalibration = false;
                    refreshCalibStatus();
                    setStatus("Kalibracja zapisana na stałe.", OK);
                } else {
                    setStatus("Zapis nie powiódł się: " + error, DANGER);
                }
            });
        });
    }

    private void confirmDiscard() {
        new AlertDialog.Builder(this)
                .setTitle("Odrzucić zmiany?")
                .setMessage("Pad uruchomi się ponownie i wróci do ostatnio zapisanej kalibracji. Połączenie na chwilę zniknie.")
                .setPositiveButton("Restartuj pad", (x, w) -> {
                    final Calibration c = cal;
                    if (c == null) return;
                    unsavedCalibration = false;
                    refreshCalibStatus();
                    io.execute(c::reboot);
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    // ================================================================== misc

    private String infoAsText() {
        if (lastInfo == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(lastInfo.model).append('\n');
        for (String[] r : lastInfo.rows) sb.append(r[0]).append(": ").append(r[1]).append('\n');
        return sb.toString();
    }

    private void shareInfo() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, infoAsText());
        startActivity(Intent.createChooser(send, "Udostępnij dane pada"));
    }

    private void copyToClipboard(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("PadTools", s));
            Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    private void setStatus(String s, int color) {
        status.setText(s);
        status.setTextColor(color);
    }

    // ================================================================== view helpers

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView subTitle(String s) {
        TextView t = text(s, 14, TEXT, true);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    private TextView hint(String s) {
        TextView t = text(s, 13, MUTED, false);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private Button button(String label, int bg) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setBackground(rounded(bg));
        b.setGravity(Gravity.CENTER);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(4), dp(10), dp(4), dp(10));
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(rounded(CARD));
        return c;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private void addWeighted(LinearLayout row, View... views) {
        for (int i = 0; i < views.length; i++) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) p.leftMargin = dp(6);
            row.addView(views[i], p);
        }
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(12));
        return g;
    }

    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(12);
        return p;
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(10);
        return p;
    }
}
