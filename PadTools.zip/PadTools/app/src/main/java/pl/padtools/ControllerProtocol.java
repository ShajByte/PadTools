package pl.padtools;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Read-only info queries for Sony controllers.
 * Ported from dualshock-tools (https://github.com/dualshock-tools/dualshock-tools.github.io, MIT license).
 * Only reads data — nothing here writes to the controller's memory.
 */
final class ControllerProtocol {

    static final int SONY_VID = 0x054C;
    static final int PID_DS4_V1 = 0x05C4;
    static final int PID_DS4_V2 = 0x09CC;
    static final int PID_DS5 = 0x0CE6;
    static final int PID_DS5_EDGE = 0x0DF2;

    private ControllerProtocol() {}

    static final class Info {
        String model = "";
        String board = "";      // e.g. BDM-030 / JDM-040
        String boardNote = "";  // short explanation under the board name
        boolean clone;
        boolean oldFirmware;
        int updateVersion;
        final List<String> warnings = new ArrayList<>();
        final List<String[]> rows = new ArrayList<>();

        void add(String k, String v) { rows.add(new String[]{k, v}); }
    }

    static boolean isSupported(int vid, int pid) {
        return vid == SONY_VID && (pid == PID_DS4_V1 || pid == PID_DS4_V2
                || pid == PID_DS5 || pid == PID_DS5_EDGE);
    }

    static boolean isDualSense(int pid) {
        return pid == PID_DS5 || pid == PID_DS5_EDGE;
    }

    static String modelName(int pid) {
        switch (pid) {
            case PID_DS4_V1: return "DualShock 4 v1 (PS4)";
            case PID_DS4_V2: return "DualShock 4 v2 (PS4)";
            case PID_DS5: return "DualSense (PS5)";
            case PID_DS5_EDGE: return "DualSense Edge (PS5)";
            default: return String.format("Nieznany (PID %04X)", pid);
        }
    }

    static Info read(HidUsbDevice h, int pid) throws IOException {
        if (isDualSense(pid)) return readDs5(h, pid == PID_DS5_EDGE);
        return readDs4(h, pid);
    }

    // ---------------------------------------------------------------- DualSense

    private static Info readDs5(HidUsbDevice h, boolean edge) throws IOException {
        Info info = new Info();
        info.model = modelName(edge ? PID_DS5_EDGE : PID_DS5);

        byte[] r = h.getFeature(0x20);
        if ((r[0] & 0xff) != 0x20 || r.length != 64) {
            throw new IOException("Nieprawidłowa odpowiedź kontrolera (raport 0x20)");
        }

        String buildDate = ascii(r, 1, 11);
        String buildTime = ascii(r, 12, 8);
        int fwType = u16(r, 20);
        int swSeries = u16(r, 22);
        long hwInfo = u32(r, 24);
        long fwVersion = u32(r, 28);
        int updVersion = u16(r, 44);
        info.updateVersion = updVersion;
        long sblFw = u32(r, 48);
        long venomFw = u32(r, 52);
        long spiderFw = u32(r, 56);

        if (edge) {
            info.board = "DualSense Edge";
            info.boardNote = "Edge ma wymienne moduły analogów – nie trzeba lutować.";
        } else {
            info.board = ds5Board(hwInfo);
            info.boardNote = "Rewizja płyty głównej (odczytana z firmware).";
        }

        String serial = systemInfo(h, 1, 19, 17, true);
        if (!edge) info.add("Model płyty", info.board);
        info.add("Kolor", serial == null ? "?" : ds5Color(serial));
        info.add("Numer seryjny", orErr(serial));
        info.add("Data firmware", buildDate + " " + buildTime);
        info.add("Wersja FW", hex32(fwVersion));
        info.add("HW Model", hex32(hwInfo));
        info.add("FW Type / Series", hex16(fwType) + " / " + hex16(swSeries));
        info.add("FW Update", hex16(updVersion));
        info.add("SBL / Venom / Spider FW", hex32(sblFw) + " / " + hex32(venomFw) + " / " + hex32(spiderFw));

        String pcba = systemInfo(h, 1, 17, 14, true);
        if (pcba != null) info.add("PCBA ID", new StringBuilder(pcba).reverse().toString());
        String mcu = systemInfo(h, 1, 9, 9, false);
        if (mcu != null) info.add("MCU Unique ID", mcu);
        String battery = systemInfo(h, 1, 24, 23, true);
        if (battery != null) info.add("Kod baterii", battery);
        String vcmL = systemInfo(h, 1, 26, 16, true);
        if (vcmL != null) info.add("Kod VCM lewy", vcmL);
        String vcmR = systemInfo(h, 1, 28, 16, true);
        if (vcmR != null) info.add("Kod VCM prawy", vcmR);
        String tpId = systemInfo(h, 5, 2, 8, false);
        if (tpId != null) info.add("Touchpad ID", tpId);
        String tpFw = systemInfo(h, 5, 4, 8, false);
        if (tpFw != null) info.add("Touchpad FW", tpFw);

        try {
            h.setFeature(0x80, 9, 2);
            byte[] bd = h.getFeature(0x81);
            info.add("Adres Bluetooth", mac(bd, 4));
        } catch (IOException ignored) {
        }

        // Clone detection (same rules as dualshock-tools)
        String cloneReason = null;
        int year = parseYear(buildDate);
        if (year > Calendar.getInstance().get(Calendar.YEAR)) {
            cloneReason = "data firmware z przyszłości";
        } else if (!ds5ModuleDataOk(h, edge)) {
            cloneReason = "brak odpowiedzi na zapytanie o moduły analogów";
        }
        info.clone = cloneReason != null;
        info.add("Typ urządzenia", info.clone ? "PODRÓBKA (" + cloneReason + ")" : "oryginał");

        if (buildDate.contains(" 2020") || buildDate.contains(" 2021")) {
            info.oldFirmware = true;
            info.warnings.add("Stary firmware (2020/2021). Zaktualizuj pada na konsoli PS5 lub w aplikacji PlayStation Accessories.");
        }
        return info;
    }

    private static boolean ds5ModuleDataOk(HidUsbDevice h, boolean edge) {
        try {
            h.setFeature(0x80, 12, edge ? 4 : 2);
            Thread.sleep(100);
            byte[] d = h.getFeature(0x81);
            int cmd = d[0] & 0xff, p1 = d[1] & 0xff, p2 = d[2] & 0xff, p3 = d[3] & 0xff;
            return cmd == 0x81 && p1 == 12 && (p2 == 2 || p2 == 4) && p3 == 2;
        } catch (Exception e) {
            return false;
        }
    }

    /** Returns null when the controller doesn't answer this query. */
    private static String systemInfo(HidUsbDevice h, int base, int num, int length, boolean decode) {
        try {
            h.setFeature(0x80, base, num);
            byte[] r = h.getFeature(0x81);
            if (r.length < 4 || (r[1] & 0xff) != base || (r[2] & 0xff) != num || (r[3] & 0xff) != 2) {
                return null;
            }
            int len = Math.min(length, r.length - 4);
            return decode ? ascii(r, 4, len) : hexBytes(r, 4, len);
        } catch (IOException e) {
            return null;
        }
    }

    static String ds5Board(long hwInfo) {
        int a = (int) ((hwInfo >> 8) & 0xff);
        switch (a) {
            case 0x03: return "BDM-010";
            case 0x04: return "BDM-020";
            case 0x05: return "BDM-030";
            case 0x06: return "BDM-040";
            case 0x07:
            case 0x08: return "BDM-050";
            case 0x09: return "BDM-060R";
            case 0x11: return "BDM-060M";
            case 0x13: return "BDM-060X";
            default: return String.format("Nieznany (0x%02X)", a);
        }
    }

    private static final Map<String, String> COLORS = new HashMap<>();
    static {
        COLORS.put("00", "White");
        COLORS.put("01", "Midnight Black");
        COLORS.put("02", "Cosmic Red");
        COLORS.put("03", "Nova Pink");
        COLORS.put("04", "Galactic Purple");
        COLORS.put("05", "Starlight Blue");
        COLORS.put("06", "Grey Camouflage");
        COLORS.put("07", "Volcanic Red");
        COLORS.put("08", "Sterling Silver");
        COLORS.put("09", "Cobalt Blue");
        COLORS.put("10", "Chroma Teal");
        COLORS.put("11", "Chroma Indigo");
        COLORS.put("12", "Chroma Pearl");
        COLORS.put("13", "HyperPop Techno Red");
        COLORS.put("14", "HyperPop Remix Green");
        COLORS.put("15", "HyperPop Rhythm Blue");
        COLORS.put("30", "30th Anniversary");
        COLORS.put("Z1", "God of War Ragnarok");
        COLORS.put("Z2", "Spider-Man 2");
        COLORS.put("Z3", "Astro Bot");
        COLORS.put("Z4", "Fortnite");
        COLORS.put("Z6", "The Last of Us");
        COLORS.put("ZA", "God of War 20th Anniversary");
        COLORS.put("ZB", "Icon Blue Limited Edition");
        COLORS.put("ZC", "Ghost of Yōtei Limited Edition");
        COLORS.put("ZD", "Marathon Limited Edition");
        COLORS.put("ZE", "Genshin Impact Limited Edition");
        COLORS.put("ZF", "007 First Light Limited Edition");
    }

    static String ds5Color(String serial) {
        if (serial.length() < 6) return "Nieznany";
        String c = COLORS.get(serial.substring(4, 6));
        return c == null ? "Nieznany" : c;
    }

    // ---------------------------------------------------------------- DualShock 4

    private static Info readDs4(HidUsbDevice h, int pid) throws IOException {
        Info info = new Info();
        info.model = modelName(pid);

        byte[] r = h.getFeature(0xA3);
        boolean clone = (r[0] & 0xff) != 0xA3 || r.length != 49;
        if (r.length < 0x2B) throw new IOException("Za krótka odpowiedź kontrolera (raport 0xA3)");

        String k1 = ascii(r, 1, 0x0F);
        String k2 = ascii(r, 0x10, 0x10);
        int hwMajor = u16(r, 0x21);
        int hwMinor = u16(r, 0x23);
        long swMajor = u32(r, 0x25);
        int swMinor = u16(r, 0x29);

        if (!clone) {
            try {
                h.getFeature(0x81, 1000);
            } catch (IOException e) {
                clone = true;
            }
        }
        info.clone = clone;

        info.board = clone ? "?" : ds4Board(hwMinor);
        info.boardNote = "Rewizja płyty głównej (odczytana z firmware).";

        if (!clone) info.add("Model płyty", info.board);
        info.add("Data firmware", (k1 + " " + k2).trim());
        info.add("Wersja HW", String.format("%04x:%04x", hwMajor, hwMinor));
        info.add("Wersja SW", String.format("%08x:%04x", swMajor, swMinor));
        if (!clone) {
            try {
                byte[] bd = h.getFeature(0x12);
                info.add("Adres Bluetooth", mac(bd, 1));
            } catch (IOException ignored) {
            }
        }
        info.add("Typ urządzenia", clone ? "PODRÓBKA" : "oryginał");
        return info;
    }

    static String ds4Board(int hwVer) {
        int a = hwVer >> 8;
        if (a == 0x31) return "JDM-001";
        if (a == 0x43) return "JDM-011";
        if (a == 0x54) return "JDM-030";
        if (a >= 0x64 && a <= 0x74) return "JDM-040";
        if ((a > 0x80 && a < 0x84) || a == 0x93) return "JDM-020";
        if (a == 0xA4 || a == 0x90 || a == 0xA0) return "JDM-050";
        if (a == 0xB0) return "JDM-055 (Scuf?)";
        if (a == 0xB4) return "JDM-055";
        int b = a >> 4;
        if ((b == 7 && a > 0x74) || (b == 9 && a != 0x93 && a != 0x90)) return "Rzadka rewizja!";
        return String.format("Nieznany (0x%02X)", a);
    }

    // ---------------------------------------------------------------- helpers

    private static int u16(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8);
    }

    private static long u32(byte[] b, int o) {
        return (b[o] & 0xffL) | ((b[o + 1] & 0xffL) << 8) | ((b[o + 2] & 0xffL) << 16) | ((b[o + 3] & 0xffL) << 24);
    }

    private static String ascii(byte[] b, int o, int len) {
        int end = Math.min(b.length, o + len);
        if (o >= end) return "";
        return new String(b, o, end - o, StandardCharsets.UTF_8).replace("\u0000", "").trim();
    }

    private static String hexBytes(byte[] b, int o, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = o; i < o + len && i < b.length; i++) sb.append(String.format("%02x", b[i] & 0xff));
        return sb.toString();
    }

    private static String mac(byte[] b, int start) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format("%02x", b[start + 5 - i] & 0xff));
        }
        return sb.toString();
    }

    private static String hex16(int v) { return String.format("0x%04x", v); }

    private static String hex32(long v) { return String.format("0x%08x", v); }

    private static String orErr(String s) { return s == null ? "błąd odczytu" : s; }

    private static int parseYear(String buildDate) {
        String t = buildDate.trim();
        if (t.length() < 4) return 0;
        try {
            return Integer.parseInt(t.substring(t.length() - 4));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
