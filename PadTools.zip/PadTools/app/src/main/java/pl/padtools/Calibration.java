package pl.padtools;

import java.io.IOException;

/**
 * Stick calibration, ported 1:1 from dualshock-tools (MIT).
 *
 * The controller keeps a new calibration in RAM until it is "flashed":
 * NVS unlock followed by NVS lock commits it to permanent memory. Until then,
 * a reboot of the pad (or unplugging it) restores the previous calibration.
 * All calls must run on the single USB worker thread.
 */
final class Calibration {

    private final HidUsbDevice hid;
    private final boolean ds5;

    Calibration(HidUsbDevice hid, boolean ds5) {
        this.hid = hid;
        this.ds5 = ds5;
    }

    // ------------------------------------------------------------ center

    void centerBegin() throws IOException {
        if (ds5) ds5Cmd(new int[]{1, 1, 1}, 0x83010101L, "rozpoczęcie kalibracji środka");
        else ds4Cmd(new int[]{1, 1, 1}, 0x91010101L, 0x920101FFL, "rozpoczęcie kalibracji środka");
    }

    void centerSample() throws IOException {
        if (ds5) ds5Cmd(new int[]{3, 1, 1}, 0x83010101L, "próbkowanie środka");
        else ds4Cmd(new int[]{3, 1, 1}, 0x91010101L, 0x920101FFL, "próbkowanie środka");
    }

    void centerEnd() throws IOException {
        if (ds5) ds5Cmd(new int[]{2, 1, 1}, 0x83010102L, "zapis kalibracji środka");
        else ds4Cmd(new int[]{2, 1, 1}, 0x91010102L, 0x92010101L, "zapis kalibracji środka");
    }

    // ------------------------------------------------------------ range

    void rangeBegin() throws IOException {
        if (ds5) ds5Cmd(new int[]{1, 1, 2}, 0x83010201L, "rozpoczęcie kalibracji zakresu");
        else ds4Cmd(new int[]{1, 1, 2}, 0x91010201L, 0x920102FFL, "rozpoczęcie kalibracji zakresu");
    }

    void rangeEnd() throws IOException {
        if (ds5) ds5Cmd(new int[]{2, 1, 2}, 0x83010202L, "zapis kalibracji zakresu");
        else ds4Cmd(new int[]{2, 1, 2}, 0x91010202L, 0x92010201L, "zapis kalibracji zakresu");
    }

    // ------------------------------------------------------------ NVS

    /** Returns true if NVS is locked (normal state), false if unlocked, null if unknown. */
    Boolean nvLocked() {
        try {
            if (ds5) {
                hid.setFeature(0x80, 3, 3);
                byte[] d = hid.getFeature(0x81);
                long ret = be32(d, 1);
                if (ret == 0x03030201L) return Boolean.TRUE;
                if (ret == 0x03030200L) return Boolean.FALSE;
                return null;
            } else {
                hid.setFeature(0x08, 0xFF, 0, 12);
                byte[] d = hid.getFeature(0x11);
                int ret = d[1] & 0xff;
                if (ret == 1) return Boolean.TRUE;
                if (ret == 0) return Boolean.FALSE;
                return null;
            }
        } catch (IOException e) {
            return null;
        }
    }

    void nvLock() throws IOException {
        if (ds5) {
            hid.setFeature(0x80, 3, 1);
            hid.getFeature(0x81);
        } else {
            hid.setFeature(0xA0, 10, 1, 0);
        }
    }

    private void nvUnlock() throws IOException {
        if (ds5) {
            hid.setFeature(0x80, 3, 2, 101, 50, 64, 12);
            hid.getFeature(0x81);
        } else {
            hid.setFeature(0xA0, 10, 2, 0x3E, 0x71, 0x7F, 0x89);
        }
    }

    /** Stores the current (temporary) calibration permanently. */
    void savePermanently() throws IOException {
        nvUnlock();
        sleep(50);
        nvLock();
    }

    /** Reboots the pad, which discards an unsaved calibration. The USB connection drops. */
    void reboot() {
        try {
            if (ds5) hid.setFeature(0x80, 1, 1);
            else hid.setFeature(0xA0, 4, 1, 0);
        } catch (IOException ignored) {
            // the pad disconnects immediately, an error here is expected
        }
    }

    // ------------------------------------------------------------ transport

    private void ds5Cmd(int[] cmd, long expected, String what) throws IOException {
        hid.setFeature(0x82, cmd);
        byte[] d = hid.getFeature(0x83);
        long got = be32(d, 0);
        if (got != expected) {
            throw new IOException(String.format("Pad odrzucił %s (odpowiedź 0x%08x)", what, got));
        }
    }

    private void ds4Cmd(int[] cmd, long exp1, long exp2, String what) throws IOException {
        hid.setFeature(0x90, cmd);
        sleep(200);
        byte[] d1 = hid.getFeature(0x91);
        byte[] d2 = hid.getFeature(0x92);
        long g1 = be32(d1, 0), g2 = be32(d2, 0);
        if (g1 != exp1 || g2 != exp2) {
            throw new IOException(String.format("Pad odrzucił %s (odpowiedź 0x%08x, 0x%08x)", what, g1, g2));
        }
    }

    private static long be32(byte[] b, int o) {
        if (b.length < o + 4) return -1;
        return ((b[o] & 0xffL) << 24) | ((b[o + 1] & 0xffL) << 16) | ((b[o + 2] & 0xffL) << 8) | (b[o + 3] & 0xffL);
    }

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
