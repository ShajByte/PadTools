package pl.padtools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Draws both analog sticks live, with their offset from center (drift check). */
final class StickView extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dead = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;

    // raw 0..255 values, written from the USB thread
    private volatile int lx = 128, ly = 128, rx = 128, ry = 128;
    private volatile boolean active;

    StickView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2 * density);
        ring.setColor(Color.parseColor("#5C6B8A"));
        grid.setStrokeWidth(1 * density);
        grid.setColor(Color.parseColor("#2E3A52"));
        dead.setStyle(Paint.Style.STROKE);
        dead.setStrokeWidth(1 * density);
        dead.setColor(Color.parseColor("#44506B"));
        dot.setColor(Color.parseColor("#4DA3FF"));
        label.setColor(Color.parseColor("#9AA7C2"));
        label.setTextSize(13 * density);
        label.setTextAlign(Paint.Align.CENTER);
        value.setTextSize(14 * density);
        value.setTextAlign(Paint.Align.CENTER);
        value.setFakeBoldText(true);
    }

    void setRaw(int lx, int ly, int rx, int ry) {
        this.lx = lx; this.ly = ly; this.rx = rx; this.ry = ry;
        this.active = true;
        postInvalidateOnAnimation();
    }

    void reset() {
        lx = ly = rx = ry = 128;
        active = false;
        postInvalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = (int) (w / 2f + 60 * density);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float half = w / 2f;
        float r = half / 2f - 14 * density;
        float cy = 22 * density + r;
        drawStick(c, half / 2f, cy, r, "Lewa gałka", lx, ly);
        drawStick(c, half + half / 2f, cy, r, "Prawa gałka", rx, ry);
    }

    private void drawStick(Canvas c, float cx, float cy, float r, String name, int rawX, int rawY) {
        c.drawText(name, cx, 14 * density, label);
        c.drawLine(cx - r, cy, cx + r, cy, grid);
        c.drawLine(cx, cy - r, cx, cy + r, grid);
        c.drawCircle(cx, cy, r * 0.1f, dead);
        c.drawCircle(cx, cy, r, ring);

        float x = norm(rawX), y = norm(rawY);
        dot.setAlpha(active ? 255 : 90);
        c.drawCircle(cx + x * r, cy + y * r, 7 * density, dot);

        double offset = Math.min(1.0, Math.hypot(x, y)) * 100.0;
        int col;
        if (!active) col = Color.parseColor("#9AA7C2");
        else if (offset < 3) col = Color.parseColor("#3DDC84");
        else if (offset < 8) col = Color.parseColor("#FFC24B");
        else col = Color.parseColor("#FF6B6B");
        value.setColor(col);
        c.drawText(active ? String.format("%.1f%%", offset) : "brak danych", cx, cy + r + 24 * density, value);
        if (active) {
            c.drawText(String.format("X %+.2f  Y %+.2f", x, y), cx, cy + r + 44 * density, label);
        }
    }

    private static float norm(int raw) {
        float v = (raw - 127.5f) / 127.5f;
        return Math.max(-1f, Math.min(1f, v));
    }
}
