package pl.padtools;

import java.io.IOException;

/**
 * Output reports: rumble, lightbar, player LEDs, mute LED, adaptive triggers
 * (DualSense) and rumble/lightbar (DualShock 4). Layout from dualshock-tools
 * and the Linux hid-playstation driver. Outputs are not stored in the pad.
 */
final class OutputController {

    private final HidUsbDevice hid;
    private final boolean ds5;
    private final boolean vibrationV2;

    private int rumbleLeft, rumbleRight;
    private int red, green = 0, blue = 255;
    private int playerLeds;
    private int muteLed;
    private int[] triggerLeft = {0, 0, 0, 0};  // mode, start, end, force
    private int[] triggerRight = {0, 0, 0, 0};

    OutputController(HidUsbDevice hid, boolean ds5, int updateVersion) {
        this.hid = hid;
        this.ds5 = ds5;
        // Newer DualSense firmware expects the "vibration v2" flag for rumble
        this.vibrationV2 = ds5 && updateVersion >= 0x0215;
    }

    synchronized void init() throws IOException {
        if (ds5) {
            send(0x0F, 0xF7);
        } else {
            send(0x03, 0);
        }
    }

    synchronized void setRumble(int left, int right) throws IOException {
        rumbleLeft = clamp(left, 255);
        rumbleRight = clamp(right, 255);
        if (ds5) send(0x03, 0); else send(0x01, 0);
    }

    synchronized void setLightbar(int r, int g, int b) throws IOException {
        red = clamp(r, 255);
        green = clamp(g, 255);
        blue = clamp(b, 255);
        if (ds5) send(0, 0x04); else send(0x02, 0);
    }

    synchronized void setPlayerLeds(int pattern) throws IOException {
        if (!ds5) return;
        playerLeds = clamp(pattern, 31);
        send(0, 0x10);
    }

    synchronized void setMuteLed(int state) throws IOException {
        if (!ds5) return;
        muteLed = clamp(state, 2);
        send(0, 0x01);
    }

    /** preset: 0 off, 1 light, 2 medium, 3 heavy (same values as dualshock-tools). */
    synchronized void setTriggerPreset(int preset) throws IOException {
        if (!ds5) return;
        int[] p;
        switch (preset) {
            case 1: p = new int[]{0x02, 10, 80, 150}; break;
            case 2: p = new int[]{0x02, 15, 100, 200}; break;
            case 3: p = new int[]{0x02, 20, 120, 255}; break;
            default: p = new int[]{0x00, 0, 0, 0}; break;
        }
        triggerLeft = p.clone();
        triggerRight = p.clone();
        send(0x0C, 0);
    }

    /** Built-in DualSense test tone through the speaker. */
    synchronized void speakerTone(boolean on) throws IOException {
        if (!ds5) return;
        if (on) {
            speakerVolume = 85;
            headphoneVolume = 55;
            send(0x10 | 0x20 | 0x80, 0);
            hid.setFeature(0x80, 6, 4, 0, 0, 8);
            hid.setFeature(0x80, 6, 2, 1, 1, 0);
        } else {
            hid.setFeature(0x80, 6, 2, 0, 1, 0);
            speakerVolume = 0;
            send(0x20 | 0x80, 0);
        }
    }

    private int speakerVolume, headphoneVolume;

    /** Turn everything off before leaving. */
    synchronized void reset() {
        try {
            rumbleLeft = rumbleRight = 0;
            triggerLeft = new int[]{0, 0, 0, 0};
            triggerRight = new int[]{0, 0, 0, 0};
            if (ds5) send(0x0F, 0); else send(0x01, 0);
        } catch (IOException ignored) {
        }
    }

    private void send(int flag0, int flag1) throws IOException {
        if (ds5) {
            boolean rumble = (flag0 & 0x03) != 0;
            if (rumble && vibrationV2) flag0 = (flag0 & ~0x03) | 0x02; // haptics select only
            byte[] b = new byte[48];
            b[0] = 0x02;
            int o = 1;
            b[o] = (byte) flag0;
            b[o + 1] = (byte) flag1;
            b[o + 2] = (byte) rumbleRight;
            b[o + 3] = (byte) rumbleLeft;
            b[o + 4] = (byte) headphoneVolume;
            b[o + 5] = (byte) speakerVolume;
            b[o + 7] = 0; // audio control
            b[o + 8] = (byte) muteLed;
            b[o + 10] = (byte) triggerRight[0];
            b[o + 11] = (byte) triggerRight[1];
            b[o + 12] = (byte) triggerRight[2];
            b[o + 13] = (byte) triggerRight[3];
            b[o + 21] = (byte) triggerLeft[0];
            b[o + 22] = (byte) triggerLeft[1];
            b[o + 23] = (byte) triggerLeft[2];
            b[o + 24] = (byte) triggerLeft[3];
            if (rumble && vibrationV2) b[o + 38] = 0x04; // valid_flag2: vibration v2
            b[o + 43] = (byte) playerLeds;
            b[o + 44] = (byte) red;
            b[o + 45] = (byte) green;
            b[o + 46] = (byte) blue;
            hid.sendOutput(b);
        } else {
            byte[] b = new byte[32];
            b[0] = 0x05;
            b[1] = (byte) flag0;
            b[2] = 0;
            b[3] = 0;
            b[4] = (byte) rumbleRight;
            b[5] = (byte) rumbleLeft;
            b[6] = (byte) red;
            b[7] = (byte) green;
            b[8] = (byte) blue;
            hid.sendOutput(b);
        }
    }

    private static int clamp(int v, int max) {
        return Math.max(0, Math.min(max, v));
    }
}
