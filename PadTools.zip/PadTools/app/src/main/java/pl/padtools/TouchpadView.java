package pl.padtools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Shows touchpad fingers and draws their trail. */
final class TouchpadView extends View {

    private static final int TRAIL = 600;

    private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pressed = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trail = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint[] finger = {new Paint(Paint.ANTI_ALIAS_FLAG), new Paint(Paint.ANTI_ALIAS_FLAG)};
    private final float density;
    private final float maxX, maxY;
    private final float[] tx = new float[TRAIL], ty = new float[TRAIL];
    private int tn, tpos;
    private boolean[] act = new boolean[2];
    private int[] xs = new int[2], ys = new int[2];
    private boolean click;
    private final RectF rect = new RectF();

    TouchpadView(Context ctx, boolean ds5) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        maxX = 1920f;
        maxY = ds5 ? 1080f : 942f;
        frame.setStyle(Paint.Style.STROKE);
        frame.setStrokeWidth(2 * density);
        frame.setColor(Color.parseColor("#5C6B8A"));
        pressed.setColor(Color.parseColor("#22405F"));
        trail.setColor(Color.parseColor("#4DA3FF"));
        trail.setAlpha(110);
        finger[0].setColor(Color.parseColor("#4DA3FF"));
        finger[1].setColor(Color.parseColor("#FFC24B"));
    }

    void update(boolean[] active, int[] x, int[] y, boolean click) {
        this.act = active;
        this.xs = x;
        this.ys = y;
        this.click = click;
        if (active[0]) {
            tx[tpos] = x[0];
            ty[tpos] = y[0];
            tpos = (tpos + 1) % TRAIL;
            if (tn < TRAIL) tn++;
        }
        invalidate();
    }

    void clear() {
        tn = 0;
        tpos = 0;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, (int) (width * maxY / maxX));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), pad = 2 * density;
        rect.set(pad, pad, w - pad, h - pad);
        if (click) c.drawRoundRect(rect, 12 * density, 12 * density, pressed);
        c.drawRoundRect(rect, 12 * density, 12 * density, frame);
        float sx = (w - 2 * pad) / maxX, sy = (h - 2 * pad) / maxY;
        for (int i = 0; i < tn; i++) {
            c.drawCircle(pad + tx[i] * sx, pad + ty[i] * sy, 2.5f * density, trail);
        }
        for (int i = 0; i < 2; i++) {
            if (act[i]) c.drawCircle(pad + xs[i] * sx, pad + ys[i] * sy, 11 * density, finger[i]);
        }
    }
}
