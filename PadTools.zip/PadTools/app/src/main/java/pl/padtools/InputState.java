package pl.padtools;

/**
 * Latest decoded input report. Written by the USB input thread, read by the UI
 * on every frame. Offsets follow dualshock-tools (WebHID data offset + 1,
 * because here index 0 is the report ID).
 */
final class InputState {

    // Button indices
    static final int UP = 0, RIGHT = 1, DOWN = 2, LEFT = 3;
    static final int SQUARE = 4, CROSS = 5, CIRCLE = 6, TRIANGLE = 7;
    static final int L1 = 8, R1 = 9, L2 = 10, R2 = 11;
    static final int CREATE = 12, OPTIONS = 13, L3 = 14, R3 = 15;
    static final int PS = 16, TOUCHPAD = 17, MUTE = 18;
    static final int FN_LEFT = 19, FN_RIGHT = 20, PADDLE_LEFT = 21, PADDLE_RIGHT = 22;
    static final int BUTTON_COUNT = 23;

    static final int RANGE_BINS = 48;

    final boolean ds5;
    final boolean edge;

    volatile int lx = 128, ly = 128, rx = 128, ry = 128;
    volatile int l2, r2;
    volatile int buttons;      // currently pressed (bit per index)
    volatile int seenButtons;  // pressed at least once since reset
    volatile boolean[] touchActive = new boolean[2];
    volatile int[] touchX = new int[2], touchY = new int[2];
    volatile float gx, gy, gz, ax, ay, az;
    volatile int battery = -1;
    volatile String batteryText = "";
    volatile long packets;
    volatile int maxL2, maxR2;

    // Range-calibration coverage (max distance per angle bin)
    private final float[] rangeLeft = new float[RANGE_BINS];
    private final float[] rangeRight = new float[RANGE_BINS];
    private volatile boolean rangeTracking;
    volatile int leftCycles, rightCycles;

    InputState(boolean ds5, boolean edge) {
        this.ds5 = ds5;
        this.edge = edge;
    }

    int buttonMask() {
        int m = (1 << 18) - 1; // 0..17 exist on every controller
        if (ds5) m |= 1 << MUTE;
        if (edge) m |= (1 << FN_LEFT) | (1 << FN_RIGHT) | (1 << PADDLE_LEFT) | (1 << PADDLE_RIGHT);
        return m;
    }

    void resetSeen() {
        seenButtons = 0;
        maxL2 = 0;
        maxR2 = 0;
    }

    /** Parses a USB input report (report ID 0x01 at index 0). */
    void parse(byte[] r, int n) {
        if (n < 10 || (r[0] & 0xff) != 0x01) return;
        lx = u8(r, 1); ly = u8(r, 2); rx = u8(r, 3); ry = u8(r, 4);

        int b;
        if (ds5) {
            if (n < 64) return;
            l2 = u8(r, 5); r2 = u8(r, 6);
            int b7 = u8(r, 8), b8 = u8(r, 9), b9 = u8(r, 10);
            b = hat(b7) | face(b7) | shoulders(b8);
            if ((b9 & 0x01) != 0) b |= 1 << PS;
            if ((b9 & 0x02) != 0) b |= 1 << TOUCHPAD;
            if ((b9 & 0x04) != 0) b |= 1 << MUTE;
            if (edge) {
                if ((b9 & 0x10) != 0) b |= 1 << FN_LEFT;
                if ((b9 & 0x20) != 0) b |= 1 << FN_RIGHT;
                if ((b9 & 0x40) != 0) b |= 1 << PADDLE_LEFT;
                if ((b9 & 0x80) != 0) b |= 1 << PADDLE_RIGHT;
            }
            imu(r, 16);
            touch(r, 33);
            ds5Battery(u8(r, 53));
        } else {
            if (n < 40) return;
            int b4 = u8(r, 5), b5 = u8(r, 6), b6 = u8(r, 7);
            l2 = u8(r, 8); r2 = u8(r, 9);
            b = hat(b4) | face(b4) | shoulders(b5);
            if ((b6 & 0x01) != 0) b |= 1 << PS;
            if ((b6 & 0x02) != 0) b |= 1 << TOUCHPAD;
            imu(r, 13);
            touch(r, 35);
            ds4Battery(u8(r, 30));
        }
        buttons = b;
        seenButtons |= b;
        if (l2 > maxL2) maxL2 = l2;
        if (r2 > maxR2) maxR2 = r2;
        packets++;

        if (rangeTracking) {
            trackRange(rangeLeft, lx, ly, true);
            trackRange(rangeRight, rx, ry, false);
        }
    }

    private static int hat(int v) {
        int h = v & 0x0F, b = 0;
        if (h == 0 || h == 1 || h == 7) b |= 1 << UP;
        if (h == 1 || h == 2 || h == 3) b |= 1 << RIGHT;
        if (h == 3 || h == 4 || h == 5) b |= 1 << DOWN;
        if (h == 5 || h == 6 || h == 7) b |= 1 << LEFT;
        return b;
    }

    private static int face(int v) {
        int b = 0;
        if ((v & 0x10) != 0) b |= 1 << SQUARE;
        if ((v & 0x20) != 0) b |= 1 << CROSS;
        if ((v & 0x40) != 0) b |= 1 << CIRCLE;
        if ((v & 0x80) != 0) b |= 1 << TRIANGLE;
        return b;
    }

    private static int shoulders(int v) {
        int b = 0;
        if ((v & 0x01) != 0) b |= 1 << L1;
        if ((v & 0x02) != 0) b |= 1 << R1;
        if ((v & 0x04) != 0) b |= 1 << L2;
        if ((v & 0x08) != 0) b |= 1 << R2;
        if ((v & 0x10) != 0) b |= 1 << CREATE;
        if ((v & 0x20) != 0) b |= 1 << OPTIONS;
        if ((v & 0x40) != 0) b |= 1 << L3;
        if ((v & 0x80) != 0) b |= 1 << R3;
        return b;
    }

    private void imu(byte[] r, int o) {
        final float gyroLsb = 14.31f, accLsb = 8192f;
        gx = s16(r, o) / gyroLsb;
        gy = s16(r, o + 2) / gyroLsb;
        gz = s16(r, o + 4) / gyroLsb;
        ax = s16(r, o + 6) / accLsb;
        ay = s16(r, o + 8) / accLsb;
        az = s16(r, o + 10) / accLsb;
    }

    private void touch(byte[] r, int o) {
        boolean[] act = new boolean[2];
        int[] xs = new int[2], ys = new int[2];
        for (int i = 0; i < 2; i++) {
            int base = o + i * 4;
            int b0 = u8(r, base), b1 = u8(r, base + 1), b2 = u8(r, base + 2), b3 = u8(r, base + 3);
            act[i] = (b0 & 0x80) == 0;
            xs[i] = ((b2 & 0x0F) << 8) | b1;
            ys[i] = (b3 << 4) | (b2 >> 4);
        }
        touchX = xs;
        touchY = ys;
        touchActive = act;
    }

    private void ds5Battery(int bat) {
        int charge = bat & 0x0f, status = bat >> 4;
        switch (status) {
            case 0: battery = Math.min(charge * 10 + 5, 100); batteryText = "na baterii"; break;
            case 1: battery = Math.min(charge * 10 + 5, 100); batteryText = "ładowanie"; break;
            case 2: battery = 100; batteryText = "naładowana"; break;
            case 15: battery = 0; batteryText = "rozładowana, ładowanie"; break;
            default: battery = -1; batteryText = "błąd baterii (kod " + status + ")"; break;
        }
    }

    private void ds4Battery(int bat) {
        int data = bat & 0x0f;
        boolean cable = ((bat >> 4) & 1) == 1;
        if (cable) {
            if (data < 10) { battery = Math.min(data * 10 + 5, 100); batteryText = "ładowanie"; }
            else if (data == 10) { battery = 100; batteryText = "ładowanie"; }
            else if (data == 11) { battery = 100; batteryText = "naładowana"; }
            else { battery = -1; batteryText = "błąd baterii"; }
        } else {
            battery = data < 10 ? data * 10 + 5 : 100;
            batteryText = "na baterii";
        }
    }

    // ------------------------------------------------------------ range tracking

    void startRangeTracking() {
        synchronized (rangeLeft) {
            java.util.Arrays.fill(rangeLeft, 0);
            java.util.Arrays.fill(rangeRight, 0);
            leftCycles = 0;
            rightCycles = 0;
        }
        rangeTracking = true;
    }

    void stopRangeTracking() {
        rangeTracking = false;
    }

    private void trackRange(float[] data, int rawX, int rawY, boolean left) {
        float x = (rawX - 127.5f) / 128f, y = (rawY - 127.5f) / 128f;
        float dist = (float) Math.hypot(x, y);
        int idx = (int) ((Math.round(Math.atan2(y, x) * RANGE_BINS / 2.0 / Math.PI) + RANGE_BINS) % RANGE_BINS);
        synchronized (rangeLeft) {
            if (dist > data[idx]) data[idx] = dist;
            int full = 0;
            for (float v : data) if (v > 0.80f) full++;
            if (full >= Math.ceil(RANGE_BINS * 0.95)) {
                java.util.Arrays.fill(data, 0);
                if (left) leftCycles++; else rightCycles++;
            }
        }
    }

    /** Fraction of the current circle covered, 0..1. */
    float rangeFill(boolean left) {
        synchronized (rangeLeft) {
            float[] d = left ? rangeLeft : rangeRight;
            int full = 0;
            for (float v : d) if (v > 0.80f) full++;
            return full / (float) RANGE_BINS;
        }
    }

    void copyRange(boolean left, float[] out) {
        synchronized (rangeLeft) {
            System.arraycopy(left ? rangeLeft : rangeRight, 0, out, 0, RANGE_BINS);
        }
    }

    // ------------------------------------------------------------ helpers

    private static int u8(byte[] b, int i) { return b[i] & 0xff; }

    private static int s16(byte[] b, int i) { return (short) ((b[i] & 0xff) | ((b[i + 1] & 0xff) << 8)); }

    static String buttonName(int i, boolean ds5) {
        switch (i) {
            case UP: return "↑";
            case RIGHT: return "→";
            case DOWN: return "↓";
            case LEFT: return "←";
            case SQUARE: return "□";
            case CROSS: return "✕";
            case CIRCLE: return "○";
            case TRIANGLE: return "△";
            case L1: return "L1";
            case R1: return "R1";
            case L2: return "L2";
            case R2: return "R2";
            case CREATE: return ds5 ? "Create" : "Share";
            case OPTIONS: return "Options";
            case L3: return "L3";
            case R3: return "R3";
            case PS: return "PS";
            case TOUCHPAD: return "Touchpad";
            case MUTE: return "Mute";
            case FN_LEFT: return "Fn L";
            case FN_RIGHT: return "Fn P";
            case PADDLE_LEFT: return "Łopatka L";
            case PADDLE_RIGHT: return "Łopatka P";
            default: return "?";
        }
    }
}
