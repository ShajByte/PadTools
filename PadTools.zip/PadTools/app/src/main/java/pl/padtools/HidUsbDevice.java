package pl.padtools;

import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

/**
 * Talks to a USB HID device through Android's USB Host API.
 * Feature reports go over control transfers (HID GET_REPORT / SET_REPORT),
 * which is exactly what WebHID does on desktop browsers.
 */
final class HidUsbDevice implements Closeable {

    private static final int TIMEOUT_MS = 1000;

    final UsbDevice device;
    private final UsbDeviceConnection conn;
    private final UsbInterface intf;
    private final UsbEndpoint inEndpoint;
    private final Map<Integer, Integer> featureSizes;

    private HidUsbDevice(UsbDevice device, UsbDeviceConnection conn, UsbInterface intf,
                         UsbEndpoint in, Map<Integer, Integer> featureSizes) {
        this.device = device;
        this.conn = conn;
        this.intf = intf;
        this.inEndpoint = in;
        this.featureSizes = featureSizes;
    }

    static HidUsbDevice open(UsbManager manager, UsbDevice device) throws IOException {
        UsbInterface hid = null;
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface it = device.getInterface(i);
            if (it.getInterfaceClass() == UsbConstants.USB_CLASS_HID) {
                hid = it;
                break;
            }
        }
        if (hid == null) throw new IOException("Nie znaleziono interfejsu HID w urządzeniu");

        UsbDeviceConnection c = manager.openDevice(device);
        if (c == null) throw new IOException("Nie można otworzyć urządzenia USB (brak uprawnień?)");

        if (!c.claimInterface(hid, true)) {
            c.close();
            throw new IOException("Nie można przejąć interfejsu HID");
        }

        UsbEndpoint in = null;
        for (int i = 0; i < hid.getEndpointCount(); i++) {
            UsbEndpoint ep = hid.getEndpoint(i);
            if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_INT
                    && ep.getDirection() == UsbConstants.USB_DIR_IN) {
                in = ep;
                break;
            }
        }

        // GET_DESCRIPTOR (HID report descriptor) to learn feature report sizes
        byte[] desc = new byte[4096];
        int n = c.controlTransfer(0x81, 0x06, 0x2200, hid.getId(), desc, desc.length, TIMEOUT_MS);
        Map<Integer, Integer> sizes = n > 0
                ? HidDescriptor.featureReportSizes(desc, n)
                : Collections.<Integer, Integer>emptyMap();

        return new HidUsbDevice(device, c, hid, in, sizes);
    }

    private int sizeOf(int reportId) {
        Integer s = featureSizes.get(reportId);
        return s != null && s > 0 ? s : 63;
    }

    /** Returns the feature report including the report ID at index 0. */
    byte[] getFeature(int reportId) throws IOException {
        return getFeature(reportId, TIMEOUT_MS);
    }

    byte[] getFeature(int reportId, int timeoutMs) throws IOException {
        byte[] buf = new byte[sizeOf(reportId) + 1];
        buf[0] = (byte) reportId;
        int n = conn.controlTransfer(0xA1, 0x01, 0x0300 | (reportId & 0xff), intf.getId(),
                buf, buf.length, timeoutMs);
        if (n <= 0) {
            throw new IOException(String.format("Brak odpowiedzi na raport 0x%02X", reportId));
        }
        return n == buf.length ? buf : Arrays.copyOf(buf, n);
    }

    /** Sends a feature report; data does not include the report ID and is zero-padded. */
    void setFeature(int reportId, int... data) throws IOException {
        int size = sizeOf(reportId);
        byte[] buf = new byte[size + 1];
        buf[0] = (byte) reportId;
        for (int i = 0; i < data.length && i < size; i++) buf[i + 1] = (byte) data[i];
        int n = conn.controlTransfer(0x21, 0x09, 0x0300 | (reportId & 0xff), intf.getId(),
                buf, buf.length, TIMEOUT_MS);
        if (n < 0) {
            throw new IOException(String.format("Nie udało się wysłać raportu 0x%02X", reportId));
        }
    }

    int inputPacketSize() {
        return inEndpoint == null ? 64 : Math.max(64, inEndpoint.getMaxPacketSize());
    }

    /** Reads one input report (with report ID at index 0). Returns length or negative on timeout/error. */
    int readInput(byte[] buf, int timeoutMs) {
        if (inEndpoint == null) return -1;
        return conn.bulkTransfer(inEndpoint, buf, buf.length, timeoutMs);
    }

    @Override
    public void close() {
        try {
            conn.releaseInterface(intf);
        } catch (Exception ignored) {
        }
        conn.close();
    }
}
