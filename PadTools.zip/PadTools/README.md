# PadTools

Android app that reads information from a PS5 DualSense / DualSense Edge or PS4 DualShock 4
over a USB cable (OTG) — the same data the desktop site
[dualshock-tools.github.io](https://dualshock-tools.github.io) shows:

- board revision (BDM-010…BDM-060 for DualSense, JDM-xxx for DualShock 4)
- firmware date and versions, serial number, color, Bluetooth address
- clone (counterfeit) check
- full input test: sticks (drift), all buttons, L2/R2, touchpad, gyroscope/accelerometer, battery, report rate
- outputs: rumble, lightbar, player LEDs, mute LED, adaptive triggers and speaker tone (DualSense)
- stick calibration (center + range) for DualSense and DualShock 4, temporary or saved permanently —
  same commands as dualshock-tools

## Getting the APK

Every push to `main` builds the app with GitHub Actions and publishes `PadTools.apk`
under **Releases → latest**. Open that page on the phone, download, and install
(allow installing from your browser when Android asks).

## Building locally

Android Studio (or Gradle 8.7+ with JDK 17): `gradle assembleDebug`.
Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Credits

Controller protocol ported from dualshock-tools (MIT).
