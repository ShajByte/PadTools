package pl.padtools;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String ACTION_USB_PERMISSION = "pl.padtools.USB_PERMISSION";

    private static final int BG = Color.parseColor("#0F1522");
    private static final int CARD = Color.parseColor("#182033");
    private static final int TEXT = Color.parseColor("#E8EDF7");
    private static final int MUTED = Color.parseColor("#9AA7C2");
    private static final int ACCENT = Color.parseColor("#4DA3FF");
    private static final int DANGER = Color.parseColor("#FF6B6B");
    private static final int WARN = Color.parseColor("#FFC24B");

    private UsbManager usb;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<String> permissionAsked = new HashSet<>();

    private volatile HidUsbDevice hid;
    private volatile int connectedPid;
    private volatile boolean reading;
    private volatile boolean connecting;
    private Thread inputThread;
    private ControllerProtocol.Info lastInfo;

    private TextView status;
    private TextView boardBig;
    private TextView boardSub;
    private TextView modelText;
    private LinearLayout boardCard;
    private LinearLayout warnBox;
    private LinearLayout infoTable;
    private LinearLayout infoCard;
    private LinearLayout stickCard;
    private StickView sticks;
    private Button shareBtn;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                scanAndConnect(false);
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice d = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                HidUsbDevice cur = hid;
                if (cur != null && d != null && d.getDeviceName().equals(cur.device.getDeviceName())) {
                    disconnect();
                    setStatus("Pad odłączony. Podłącz go ponownie kablem USB.", MUTED);
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                scanAndConnect(true);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(usbReceiver, f);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
            scanAndConnect(true);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (hid == null) {
            scanAndConnect(false);
        } else {
            startInput();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopInput();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(usbReceiver);
        } catch (Exception ignored) {
        }
        disconnect();
        io.shutdownNow();
    }

    // ------------------------------------------------------------------ USB flow

    private UsbDevice findController() {
        for (UsbDevice d : usb.getDeviceList().values()) {
            if (ControllerProtocol.isSupported(d.getVendorId(), d.getProductId())) return d;
        }
        for (UsbDevice d : usb.getDeviceList().values()) {
            if (d.getVendorId() == ControllerProtocol.SONY_VID) return d;
        }
        return null;
    }

    private void scanAndConnect(boolean mayAskPermission) {
        if (hid != null || connecting) return;
        UsbDevice d = findController();
        if (d == null) {
            setStatus("Nie wykryto pada. Podłącz DualSense lub DualShock 4 kablem USB (OTG) do telefonu.", MUTED);
            return;
        }
        if (!ControllerProtocol.isSupported(d.getVendorId(), d.getProductId())) {
            setStatus(String.format("Wykryto urządzenie Sony (PID %04X), ale ten model nie jest obsługiwany.", d.getProductId()), WARN);
            return;
        }
        if (!usb.hasPermission(d)) {
            if (!mayAskPermission && permissionAsked.contains(d.getDeviceName())) {
                setStatus("Brak zgody na dostęp do pada. Stuknij „Połącz”, aby zapytać ponownie.", WARN);
                return;
            }
            permissionAsked.add(d.getDeviceName());
            setStatus("Zezwól aplikacji na dostęp do pada w oknie systemowym…", ACCENT);
            Intent i = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
            int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
            PendingIntent pi = PendingIntent.getBroadcast(this, 0, i, flags);
            usb.requestPermission(d, pi);
            return;
        }
        connect(d);
    }

    private void connect(final UsbDevice d) {
        connecting = true;
        setStatus("Łączenie z " + ControllerProtocol.modelName(d.getProductId()) + "…", ACCENT);
        io.execute(() -> {
            HidUsbDevice h = null;
            try {
                h = HidUsbDevice.open(usb, d);
                final ControllerProtocol.Info info = ControllerProtocol.read(h, d.getProductId());
                hid = h;
                connectedPid = d.getProductId();
                main.post(() -> {
                    connecting = false;
                    showInfo(info);
                    setStatus("Połączono przez USB.", Color.parseColor("#3DDC84"));
                    startInput();
                });
            } catch (Exception e) {
                if (h != null) h.close();
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                main.post(() -> {
                    connecting = false;
                    setStatus("Błąd: " + msg + "\nOdłącz i podłącz pada ponownie, potem stuknij „Połącz”.", DANGER);
                });
            }
        });
    }

    private void disconnect() {
        stopInput();
        HidUsbDevice h = hid;
        hid = null;
        if (h != null) h.close();
        if (sticks != null) sticks.reset();
    }

    private void startInput() {
        final HidUsbDevice h = hid;
        if (h == null || reading) return;
        reading = true;
        final boolean ds5 = ControllerProtocol.isDualSense(connectedPid);
        inputThread = new Thread(() -> {
            byte[] buf = new byte[h.inputPacketSize()];
            int errors = 0;
            while (reading) {
                int n = h.readInput(buf, 200);
                if (n >= 5 && (buf[0] & 0xff) == 0x01) {
                    errors = 0;
                    sticks.setRaw(buf[1] & 0xff, buf[2] & 0xff, buf[3] & 0xff, buf[4] & 0xff);
                } else if (n < 0) {
                    // timeouts are normal when idle; many errors in a row mean the pad is gone
                    if (++errors > 50) break;
                }
            }
            reading = false;
        }, ds5 ? "ds5-input" : "ds4-input");
        inputThread.start();
    }

    private void stopInput() {
        reading = false;
        Thread t = inputThread;
        inputThread = null;
        if (t != null) {
            try {
                t.join(500);
            } catch (InterruptedException ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(root);

        TextView title = text("PadTools", 26, TEXT, true);
        root.addView(title);
        TextView sub = text("Informacje o padzie PS5 / PS4 przez kabel USB", 14, MUTED, false);
        sub.setPadding(0, dp(2), 0, dp(14));
        root.addView(sub);

        status = text("", 14, MUTED, false);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.setBackground(rounded(CARD));
        root.addView(status, lp());

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, dp(10), 0, dp(4));
        Button connectBtn = button("Połącz", ACCENT);
        connectBtn.setOnClickListener(v -> {
            disconnect();
            scanAndConnect(true);
        });
        shareBtn = button("Udostępnij", CARD);
        shareBtn.setEnabled(false);
        shareBtn.setOnClickListener(v -> shareInfo());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bl.rightMargin = dp(6);
        buttons.addView(connectBtn, bl);
        LinearLayout.LayoutParams br = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        br.leftMargin = dp(6);
        buttons.addView(shareBtn, br);
        root.addView(buttons, lp());

        // Board card
        boardCard = card();
        modelText = text("", 14, MUTED, false);
        boardCard.addView(modelText);
        boardBig = text("", 34, TEXT, true);
        boardBig.setPadding(0, dp(2), 0, dp(2));
        boardCard.addView(boardBig);
        boardSub = text("", 13, MUTED, false);
        boardCard.addView(boardSub);
        boardCard.setVisibility(View.GONE);
        root.addView(boardCard, cardLp());

        warnBox = new LinearLayout(this);
        warnBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(warnBox, lp());

        // Sticks card
        stickCard = card();
        stickCard.addView(sectionTitle("Test analogów"));
        TextView hint = text("Puść gałki i sprawdź odchylenie od środka. Zielone (poniżej 3%) = bez dryfu.", 13, MUTED, false);
        hint.setPadding(0, 0, 0, dp(8));
        stickCard.addView(hint);
        sticks = new StickView(this);
        stickCard.addView(sticks, lp());
        stickCard.setVisibility(View.GONE);
        root.addView(stickCard, cardLp());

        // Info table
        infoCard = card();
        infoCard.addView(sectionTitle("Szczegóły"));
        infoTable = new LinearLayout(this);
        infoTable.setOrientation(LinearLayout.VERTICAL);
        infoCard.addView(infoTable, lp());
        infoCard.setVisibility(View.GONE);
        root.addView(infoCard, cardLp());

        TextView help = text(
                "Jak podłączyć: użyj kabla USB-C ↔ USB-C (dla PS5) albo przejściówki OTG + kabla micro-USB (dla PS4). "
                        + "Bluetooth nie jest obsługiwany. Aplikacja tylko odczytuje dane – niczego nie zapisuje w padzie.\n\n"
                        + "Na podstawie projektu dualshock-tools (licencja MIT).",
                12, MUTED, false);
        help.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(help, lp());

        return scroll;
    }

    private void showInfo(ControllerProtocol.Info info) {
        lastInfo = info;
        modelText.setText(info.model);
        boardBig.setText(info.clone ? "Podróbka?" : info.board);
        boardBig.setTextColor(info.clone ? DANGER : TEXT);
        boardSub.setText(info.clone
                ? "Pad nie odpowiada jak oryginalny kontroler Sony – dane mogą być niewiarygodne."
                : info.boardNote);
        boardCard.setVisibility(View.VISIBLE);

        warnBox.removeAllViews();
        for (String w : info.warnings) {
            TextView t = text("⚠ " + w, 13, WARN, false);
            t.setPadding(dp(14), dp(10), dp(14), dp(10));
            t.setBackground(rounded(CARD));
            LinearLayout.LayoutParams p = lp();
            p.topMargin = dp(10);
            warnBox.addView(t, p);
        }

        infoTable.removeAllViews();
        for (String[] row : info.rows) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.VERTICAL);
            r.setPadding(0, dp(7), 0, dp(7));
            r.addView(text(row[0], 12, MUTED, false));
            TextView v = text(row[1], 15, row[1].startsWith("PODRÓBKA") ? DANGER : TEXT, false);
            v.setTypeface(Typeface.MONOSPACE);
            v.setTextIsSelectable(true);
            r.addView(v);
            final String copy = row[1];
            r.setOnLongClickListener(x -> {
                copyToClipboard(copy);
                return true;
            });
            infoTable.addView(r, lp());
        }
        infoCard.setVisibility(View.VISIBLE);
        stickCard.setVisibility(View.VISIBLE);
        shareBtn.setEnabled(true);
    }

    private String infoAsText() {
        if (lastInfo == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(lastInfo.model).append('\n');
        for (String[] r : lastInfo.rows) sb.append(r[0]).append(": ").append(r[1]).append('\n');
        return sb.toString();
    }

    private void shareInfo() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, infoAsText());
        startActivity(Intent.createChooser(send, "Udostępnij dane pada"));
    }

    private void copyToClipboard(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("PadTools", s));
            Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show();
        }
    }

    private void setStatus(String s, int color) {
        status.setText(s);
        status.setTextColor(color);
    }

    // ------------------------------------------------------------------ view helpers

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 17, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private Button button(String label, int bg) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setBackground(rounded(bg));
        b.setGravity(Gravity.CENTER);
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(rounded(CARD));
        return c;
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(14));
        return g;
    }

    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(12);
        return p;
    }
}
